class HelloWorld
{
	public static int main(int a)
	{
		int b = 0;
		while (b < 6){
			b = b + 1;
		}
	}
}