class HelloWorld
{
    public static int main(int intk)
    {
        int x = 5;
        if(x == (7)-2){
            System.out.println(x);
            string x1= "try;";
            System.out.println(x1);
            return 0;
            System.out.println("Please, run it on a Server!");
        }
    }
}