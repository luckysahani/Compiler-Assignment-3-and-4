class HelloWorld
{
	public static int main(int a)
	{
		int sum = 5;
		int b = sum < 5 ? 3 : 4;
	}
}