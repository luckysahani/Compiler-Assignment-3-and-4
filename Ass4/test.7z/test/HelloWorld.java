class HelloWorld
{
	public static void func(int k){
		System.out.println("Good Job \n");
	}
	int y,x;
	public static int main(int b){
		func(9);
	}
}

