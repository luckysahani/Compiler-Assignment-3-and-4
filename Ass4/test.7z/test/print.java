class HelloWorld
{
	public static int main()
	{
		int sum = 5;
		int k;
		k = sum + 5;
	}
}