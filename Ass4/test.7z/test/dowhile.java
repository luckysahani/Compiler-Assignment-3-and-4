class HelloWorld
{
	public static int main(int a)
	{
		int b = 0;
		do{
			b = b + 1;
		}
		while (b < 6);
	}
}